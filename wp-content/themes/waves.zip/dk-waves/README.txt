DOCUMENTATION
===========================================================================
In the unzipped folder, locate file documentation/docs.html


CHANGELOG
============================================================================
Version 1.0	11. 05. 2017	
Initial Release

Version 1.1	15. 05. 2017
Minor CSS fixes
Documentation extended
Added tagline under logo, but hidden with CSS
Video header in posts

Version 1.2	27. 05. 2017
Responsive CSS fixes
On mobile, hide the video to save bandwidth

Version 1.3	01. 06. 2017
Zoom-out fix on mobile