<?php if ( is_active_sidebar( 'footer' ) ) : ?>
	
	<div class="widgets">		
		<?php dynamic_sidebar( 'footer' );  ?>
	</div>

<?php endif; ?>